<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (!empty($_SESSION['admin_id'])) {
    redirect('admin/dashboard.php');
}
if (!empty($_SESSION['user_id'])) {
    redirect('customer/home.php');
}
redirect('auth/login.php');
