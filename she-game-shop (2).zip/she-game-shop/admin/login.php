<?php
require_once dirname(__DIR__) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/includes/layout.php';
if(admin_user())redirect('admin/dashboard.php');
if((int)db()->query('SELECT COUNT(*) FROM admins')->fetchColumn()===0)redirect('admin/setup-admin.php');
$errors=[];
if(is_post()){
 verify_csrf();$email=strtolower(trim((string)($_POST['email']??'')));$password=(string)($_POST['password']??'');
 if((int)($_SESSION['admin_blocked_until']??0)>time())$errors[]='Too many attempts. Try again later.';else{$stmt=db()->prepare('SELECT * FROM admins WHERE email=? AND is_active=1');$stmt->execute([$email]);$admin=$stmt->fetch();if(!$admin||!password_verify($password,$admin['password_hash'])){$_SESSION['admin_attempts']=(int)($_SESSION['admin_attempts']??0)+1;if($_SESSION['admin_attempts']>=5)$_SESSION['admin_blocked_until']=time()+300;$errors[]='Email or password is incorrect.';}else{unset($_SESSION['admin_attempts'],$_SESSION['admin_blocked_until']);session_regenerate_id(true);$_SESSION['admin_id']=(int)$admin['id'];db()->prepare('UPDATE admins SET last_login_at=NOW() WHERE id=?')->execute([$admin['id']]);redirect('admin/dashboard.php');}}
}
render_header('Admin login');
?>
<?php $shop=shop_settings(); ?><div class="auth-wrap"><section class="auth-card"><div class="brand"><img class="brand-logo" src="<?=e(public_image($shop['logo_path'],'default-logo.svg'))?>" alt=""><span><?=e($shop['shop_name'])?> <b>ADMIN</b></span></div><p class="eyebrow">Restricted access</p><h2>Administrator login</h2><?php if($errors):?><div class="form-errors"><?php foreach($errors as $error):?><div><?=e($error)?></div><?php endforeach;?></div><?php endif;?><form method="post"><?=csrf_field()?><div class="form-group"><label>Email</label><input type="email" name="email" required></div><div class="form-group"><label>Password</label><input type="password" name="password" required></div><button class="button">Log in</button></form></section></div>
<?php render_footer();?>
