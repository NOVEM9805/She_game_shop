<?php
require_once dirname(__DIR__) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/includes/layout.php';
$admin = require_admin();

if (is_post()) {
    verify_csrf();
    $id = (int) ($_POST['order_id'] ?? 0);
    $status = (string) ($_POST['status'] ?? '');
    $reason = trim((string) ($_POST['reason'] ?? ''));
    $allowed = ['processing', 'completed', 'rejected', 'cancelled'];
    if (in_array($status, $allowed, true)) {
        $stmt = db()->prepare('SELECT user_id,order_number FROM orders WHERE id=?');
        $stmt->execute([$id]);
        $order = $stmt->fetch();
        if ($order) {
            db()->prepare('UPDATE orders SET status=?,rejection_reason=? WHERE id=?')->execute([$status, in_array($status, ['rejected', 'cancelled'], true) ? $reason : null, $id]);
            notify_user((int) $order['user_id'], 'Order updated', 'Order ' . $order['order_number'] . ' is now ' . str_replace('_', ' ', $status) . '.', $id);
            log_admin((int) $admin['id'], 'Changed order status to ' . $status, 'order', $id);
            flash('success', 'Order status updated.');
        }
    }
    redirect('admin/orders.php');
}

$filter = (string) ($_GET['status'] ?? '');
$allowedFilters = ['pending_payment', 'payment_reviewing', 'processing', 'completed', 'rejected', 'cancelled'];
$sql = 'SELECT o.*,u.username,u.email,g.name game_name,oi.item_name,p.method FROM orders o JOIN users u ON u.id=o.user_id JOIN games g ON g.id=o.game_id JOIN order_items oi ON oi.order_id=o.id LEFT JOIN payments p ON p.order_id=o.id';
$params = [];
if (in_array($filter, $allowedFilters, true)) { $sql .= ' WHERE o.status=?'; $params[] = $filter; }
$sql .= ' ORDER BY o.created_at DESC';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();
render_header('Orders', 'admin');
?>
<div class="section-head">
    <div><p class="eyebrow">Fulfilment</p><h1>Orders</h1><p>Review player information and update fulfilment status.</p></div>
    <form class="filter-form" method="get"><label class="sr-only" for="status-filter">Order status</label><select id="status-filter" name="status" onchange="this.form.submit()"><option value="">All statuses</option><?php foreach ($allowedFilters as $option): ?><option value="<?= $option ?>" <?= $filter === $option ? 'selected' : '' ?>><?= e(str_replace('_', ' ', $option)) ?></option><?php endforeach; ?></select></form>
</div>
<?php if (!$orders): ?><div class="empty">No orders match this status.</div><?php else: ?>
<div class="table-wrap card-table-wrap">
<table class="mobile-card-table order-admin-table">
    <thead><tr><th>Order</th><th>Customer</th><th>Item</th><th>Player details</th><th>Total</th><th>Status</th><th>Update</th></tr></thead>
    <tbody><?php foreach ($orders as $order): ?><tr>
        <td data-label="Order" class="table-primary"><strong><?= e($order['order_number']) ?></strong><small><?= e(date('d M Y H:i', strtotime($order['created_at']))) ?></small></td>
        <td data-label="Customer"><strong><?= e($order['username']) ?></strong><small><?= e($order['email']) ?></small></td>
        <td data-label="Item"><strong><?= e($order['game_name']) ?></strong><small><?= e($order['item_name']) ?></small></td>
        <td data-label="Player"><span>ID: <?= e($order['player_id']) ?></span><?php if ($order['zone_id']): ?><small>Zone/Tag: <?= e($order['zone_id']) ?></small><?php endif; ?><small>Name: <?= e($order['player_name']) ?></small></td>
        <td data-label="Total"><strong><?= money($order['total_amount'], $order['currency']) ?></strong></td>
        <td data-label="Status"><span class="badge <?= status_class($order['status']) ?>"><?= e(str_replace('_', ' ', $order['status'])) ?></span></td>
        <td data-label="Update" class="table-actions"><form class="table-control-form" method="post"><?= csrf_field() ?><input type="hidden" name="order_id" value="<?= (int) $order['id'] ?>"><select name="status" aria-label="New status"><option value="processing">Processing</option><option value="completed">Completed</option><option value="rejected">Rejected</option><option value="cancelled">Cancelled</option></select><input name="reason" placeholder="Reason if rejected"><button class="button small">Update order</button></form></td>
    </tr><?php endforeach; ?></tbody>
</table>
</div>
<?php endif; ?>
<?php render_footer(); ?>
