# SHE Game Shop

A responsive bilingual PHP/MySQL game item ordering website with customer and administrator systems.

## Included features

- Customer registration, secure password hashing, login and logout
- Six-digit email OTP verification and a separated, step-by-step password reset flow
- English/Myanmar customer interface
- Instant game-name prefix search from the navigation bar (no Enter key required)
- Dynamic player-information forms for eight games
- MMK and GBP price display
- KBZPay and Wave Money receipt submission with admin verification
- PayPal and card placeholders in safe test mode
- Order confirmation, tracking, notifications and printable receipts
- Customer profile photo, password change, rankings, FAQ and support tickets
- Admin dashboard, catalog CRUD, promotions, payments, orders, customers, support and reports
- Admin-uploaded game covers, item images, promotion banners, shop logo and favicon
- Hot Games followed by all other active games, expandable icon search and responsive promotion slideshow
- Game-by-game admin item management instead of one mixed item list
- Screen-safe responsive layouts for desktop, tablet and phone widths, including internally scrollable management tables
- Automatic creation of the protected payment-proof folder when a customer submits a screenshot
- Prepared statements, CSRF protection, login throttling and protected payment screenshots

## Requirements

- XAMPP with PHP 8.1 or newer
- MySQL/MariaDB
- PHP extensions: PDO MySQL, fileinfo and mbstring
- Composer only when real SMTP email is required

## Installation with XAMPP

1. Extract the `she-game-shop` folder into:

   `C:\xampp\htdocs\she-game-shop`

2. Start **Apache** and **MySQL** from the XAMPP Control Panel.

3. Open `http://localhost/phpmyadmin`.

4. Select **Import**, choose `database/schema.sql`, and import it. The script creates the `she_game_shop` database, tables, games and sample items.

5. Open `.env` and confirm these values match your computer:

   ```env
   APP_URL=http://localhost/she-game-shop
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_NAME=she_game_shop
   DB_USER=root
   DB_PASS=
   ```

6. Visit `http://localhost/she-game-shop/admin/setup-admin.php` and create the first administrator account. The setup page disables itself after the first administrator is created.

7. Visit `http://localhost/she-game-shop` to register a customer account.

### Updating an existing installation

Keep your existing `.env`, replace the application files, and import `database/database_update.sql` once into the existing `she_game_shop` database. Do not re-import the full schema when preserving existing customer and order data.

If `database_update.sql` was already imported for the image/logo version, these latest layout, search and password-reset improvements need only the new PHP/CSS/JavaScript files. Running the update SQL again is safe because it uses `IF NOT EXISTS`.

## Testing OTP without email configuration

The included `.env` uses:

```env
MAIL_MODE=log
```

After registering, open `storage/logs/mail.log`. The six-digit OTP is written there for local demonstration. Do not use log mode on a public website.

## Enabling real Gmail OTP

1. Install Composer from `https://getcomposer.org/`.
2. Open a terminal inside the project folder and run:

   ```bash
   composer install
   ```

3. Enable two-step verification on the sender Gmail account and create a Google App Password.
4. Update `.env`:

   ```env
   MAIL_MODE=smtp
   MAIL_USERNAME=yourshop@gmail.com
   MAIL_APP_PASSWORD=your-16-character-app-password
   MAIL_FROM_ADDRESS=yourshop@gmail.com
   ```

5. Never publish the `.env` file or send its credentials to customers.

## Payment configuration

Use **Admin → Settings** to update the shop logo, shop name and manual payment accounts. `.env` values are used as a fallback until the settings are saved.

```env
KBZPAY_NAME="Your Shop Name"
KBZPAY_PHONE=09xxxxxxxxx
WAVE_NAME="Your Shop Name"
WAVE_PHONE=09xxxxxxxxx
```

KBZPay and Wave Money use manual verification:

1. Customer transfers the exact order amount.
2. Customer submits payer details, Transaction ID and screenshot.
3. Order becomes `payment_reviewing`.
4. Admin compares the submission with the real KPay/Wave transaction history.
5. Admin approves or rejects the payment.

Screenshots are stored under `storage/private/payment-proofs` and can only be viewed through an authenticated administrator page.

## PayPal and card payments

PayPal and Stripe/card choices are visibly marked as **test mode**. They do not collect real card details. Real payments require merchant accounts, API credentials, webhook verification and HTTPS before launch.

## Game player fields

| Game | Fields shown at checkout |
|---|---|
| Mobile Legends | User ID, Zone ID, In-game Name |
| Valorant | Riot ID, Tagline, Account Region, In-game Name |
| Free Fire | Player ID, In-game Name |
| PUBG Mobile | Player ID, In-game Name |
| Clash of Clans | Player Tag, In-game Name |
| Magic Chess: Go Go | User ID, Zone ID, In-game Name |
| Genshin Impact | UID, Server, In-game Name |
| Wuthering Waves | User ID/UID, Server, In-game Name |

No game API is used. Player names are manually entered and are not automatically verified.

## Main URLs

- Customer website: `http://localhost/she-game-shop`
- First admin setup: `http://localhost/she-game-shop/admin/setup-admin.php`
- Admin login: `http://localhost/she-game-shop/admin/login.php`
- phpMyAdmin: `http://localhost/phpmyadmin`

## Before public deployment

- Change `APP_ENV` to `production`.
- Use HTTPS.
- Set a strong MySQL password and a restricted database user.
- Enable real SMTP and confirm email delivery.
- Replace the KPay/Wave placeholder account details.
- Configure production PayPal/Stripe integrations only with official merchant credentials.
- Schedule backups for the database and private payment files.
- Keep `.env`, database backups and payment screenshots outside public access.

## Project structure

```text
she-game-shop/
├── admin/              Admin dashboard and management pages
├── assets/             External CSS, JavaScript and favicon
├── auth/               Login, registration, OTP and password reset
├── config/             Application and database configuration
├── customer/           Store, checkout, payment, orders and profile
├── database/           MySQL schema and sample catalog data
├── includes/           Shared security, helpers and layouts
├── lang/               English and Myanmar translations
├── storage/private/    Protected payment screenshots
├── storage/logs/       Local OTP log
├── uploads/            Profile, game, item, promotion and branding images
├── .env                Local settings (never publish credentials)
└── index.php            Website entry point
```
